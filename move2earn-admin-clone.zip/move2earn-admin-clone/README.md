# Move2Earn-inspired UI + Admin (demo)

Bản dựng độc lập theo phong cách giao diện trong ảnh tham khảo. Đây **không phải website chính thức** và không tích hợp ví, token, nạp/rút tiền, giao dịch blockchain hay phát thưởng thật.

## Có gì trong source
- Responsive frontend mobile-first với 5 tab điều hướng.
- Trang quản trị tại `/admin/login`.
- Đăng nhập admin bằng mật khẩu bcrypt lấy từ biến môi trường.
- SQLite lưu dữ liệu demo, thêm người dùng demo, chỉnh điểm demo, đổi trạng thái, nhật ký thao tác.
- Giới hạn thử đăng nhập, cookie `HttpOnly`/`SameSite=Strict`, Helmet security headers.
- Docker Compose, Dockerfile và cấu hình Nginx mẫu.

## 1. Yêu cầu
- Node.js 20+ và npm; hoặc Docker + Docker Compose.
- Một máy chủ Ubuntu/Debian nếu triển khai public.

## 2. Chạy local
```bash
cp .env.example .env
```
Tạo hash bcrypt cho mật khẩu quản trị:
```bash
node -e "const b=require('bcryptjs'); b.hash(process.argv[1],12).then(console.log)" 'DoiMatKhauThatManh!'
```
Sao chép kết quả hash vào `ADMIN_PASSWORD_HASH` trong `.env`. Thay `SESSION_SECRET` bằng chuỗi ngẫu nhiên dài ít nhất 32 ký tự. Ví dụ tạo secret:
```bash
openssl rand -hex 32
```
Cài và chạy:
```bash
npm install
npm start
```
Mở `http://127.0.0.1:3000`; trang admin: `http://127.0.0.1:3000/admin/login`.

**Không** dùng mật khẩu ví crypto hoặc mật khẩu đã sử dụng ở nơi khác. Không commit `.env` vào Git.

## 3. Triển khai VPS với domain
Ví dụ dùng Ubuntu 22.04/24.04, Nginx và Docker Compose:
1. Trỏ bản ghi DNS `A` của tên miền về IP VPS.
2. Cài Docker Engine và Docker Compose plugin.
3. Upload source lên VPS, tạo `.env` theo bước trên.
4. Build/chạy:
   ```bash
   docker compose up -d --build
   docker compose logs -f
   ```
5. Cài Nginx và tạo virtual host từ `deploy/nginx.conf.example`; thay `example.com` bằng domain của bạn.
6. Cấp HTTPS bằng Certbot:
   ```bash
   sudo certbot --nginx -d example.com -d www.example.com
   ```
7. Kiểm tra `https://example.com` và `https://example.com/admin/login`.

Docker Compose chỉ bind ứng dụng vào `127.0.0.1:3000`; Nginx làm reverse proxy công khai. `TRUST_PROXY=1` được cấu hình cho trường hợp TLS kết thúc tại Nginx. Hãy chắc chắn chỉ proxy đáng tin cậy được phép truy cập cổng ứng dụng.

## 4. Sao lưu và vận hành
- Database: `data/app.sqlite` (khi Docker chạy, thư mục `./data` được mount vào container).
- Sao lưu định kỳ file SQLite khi ứng dụng đã dừng hoặc dùng công cụ backup SQLite phù hợp.
- Cập nhật hệ điều hành và dependencies, giám sát log, giới hạn quyền SSH, bật firewall chỉ cho 22/80/443.
- Dùng session store bền vững (ví dụ Redis) nếu chạy nhiều instance; mặc định Express MemoryStore chỉ phù hợp demo/instance đơn.
- Trước khi dùng cho người dùng thật, cần rà soát bảo mật, CSRF protection, quy trình reset mật khẩu, xác minh email, chính sách riêng tư, điều khoản và pháp lý phù hợp.

## 5. Giới hạn quan trọng
- Các điểm trong admin là dữ liệu demo có thể chỉnh sửa; chúng không đại diện tài sản thật.
- Không có wallet connect, không yêu cầu seed phrase/private key, không giao dịch token.
- Chỉ sử dụng tên, logo và tài sản thương hiệu mà bạn có quyền sử dụng. Hãy giữ thông báo dự án độc lập rõ ràng để tránh nhầm với website khác.
