require("dotenv").config();

const path = require("path");
const fs = require("fs");
const express = require("express");
const session = require("express-session");
const SQLiteStoreFactory = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DB_PATH = path.resolve(process.env.DATABASE_PATH || "./data/app.sqlite");
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error("ERROR: SESSION_SECRET must be set and contain at least 32 characters.");
  process.exit(1);
}
if (!process.env.ADMIN_PASSWORD_HASH || !process.env.ADMIN_PASSWORD_HASH.startsWith("$2")) {
  console.error("ERROR: Set ADMIN_PASSWORD_HASH in .env to a bcrypt hash. See README.md.");
  process.exit(1);
}

if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(express.json({ limit: "20kb" }));

const db = new SQLiteStoreFactory(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS demo_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    display_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    points INTEGER NOT NULL DEFAULT 0 CHECK(points >= 0),
    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','paused')),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    detail TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);
const count = db.prepare("SELECT COUNT(*) AS n FROM demo_users").get().n;
if (count === 0) {
  const insert = db.prepare("INSERT INTO demo_users(display_name,email,points,status) VALUES(?,?,?,?)");
  const seed = db.transaction(() => {
    insert.run("Demo User 01", "demo01@example.test", 1250, "active");
    insert.run("Demo User 02", "demo02@example.test", 500, "active");
    insert.run("Demo User 03", "demo03@example.test", 0, "paused");
  });
  seed();
}
const addLog = db.prepare("INSERT INTO activity_logs(action,detail) VALUES(?,?)");

app.use(session({
  name: "m2e.admin.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 4
  }
  // For multi-instance production, replace MemoryStore with a persistent session store.
}));

app.use(express.static(path.join(__dirname, "public"), { index: "index.html" }));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: "Quá nhiều lần đăng nhập. Vui lòng thử lại sau 15 phút."
});

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin === true) return next();
  return res.redirect("/admin/login");
}
function safeText(value, max = 120) {
  return String(value ?? "").trim().slice(0, max);
}
function render(view, data = {}) {
  let html = fs.readFileSync(path.join(__dirname, "views", view), "utf8");
  for (const [key, value] of Object.entries(data)) {
    html = html.replaceAll(`{{${key}}}`, String(value));
  }
  return html;
}

app.get("/health", (_req, res) => res.json({ ok: true }));

app.get("/admin", requireAdmin, (_req, res) => res.redirect("/admin/dashboard"));
app.get("/admin/login", (req, res) => {
  if (req.session?.isAdmin) return res.redirect("/admin/dashboard");
  res.type("html").send(render("login.html", { error: "" }));
});
app.post("/admin/login", loginLimiter, async (req, res, next) => {
  try {
    const username = safeText(req.body.username, 100);
    const password = String(req.body.password || "");
    const expectedUsername = process.env.ADMIN_USERNAME || "admin";
    const validUser = username === expectedUsername;
    const validPassword = await bcrypt.compare(password, process.env.ADMIN_PASSWORD_HASH);
    if (!validUser || !validPassword) {
      addLog.run("LOGIN_FAILED", `Failed login attempt for username: ${username.slice(0, 80)}`);
      return res.status(401).type("html").send(render("login.html", {
        error: "Thông tin đăng nhập không đúng."
      }));
    }
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.isAdmin = true;
      req.session.adminUsername = expectedUsername;
      addLog.run("LOGIN_SUCCESS", `Admin ${expectedUsername} logged in`);
      res.redirect("/admin/dashboard");
    });
  } catch (err) { next(err); }
});
app.post("/admin/logout", requireAdmin, (req, res, next) => {
  addLog.run("LOGOUT", `Admin ${req.session.adminUsername || "admin"} logged out`);
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("m2e.admin.sid", { httpOnly: true, sameSite: "strict" });
    res.redirect("/admin/login");
  });
});

app.get("/admin/dashboard", requireAdmin, (req, res) => {
  const stats = {
    users: db.prepare("SELECT COUNT(*) AS n FROM demo_users").get().n,
    active: db.prepare("SELECT COUNT(*) AS n FROM demo_users WHERE status='active'").get().n,
    points: db.prepare("SELECT COALESCE(SUM(points),0) AS n FROM demo_users").get().n,
    logs: db.prepare("SELECT COUNT(*) AS n FROM activity_logs").get().n
  };
  const users = db.prepare("SELECT id,display_name,email,points,status,created_at FROM demo_users ORDER BY id DESC").all();
  const logs = db.prepare("SELECT action,detail,created_at FROM activity_logs ORDER BY id DESC LIMIT 8").all();
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
  const userRows = users.map(u => `<tr>
    <td>${u.id}</td><td>${esc(u.display_name)}</td><td>${esc(u.email)}</td>
    <td><form class="inline" method="post" action="/admin/users/${u.id}/points">
      <input aria-label="Điểm demo" type="number" min="0" max="100000000" name="points" value="${u.points}" required>
      <button class="small" type="submit">Lưu điểm</button></form></td>
    <td><span class="status ${u.status}">${u.status === "active" ? "Hoạt động" : "Tạm dừng"}</span></td>
    <td><form method="post" action="/admin/users/${u.id}/status"><input type="hidden" name="status" value="${u.status === "active" ? "paused" : "active"}"><button class="small ghost" type="submit">${u.status === "active" ? "Tạm dừng" : "Kích hoạt"}</button></form></td>
  </tr>`).join("");
  const logRows = logs.map(l => `<tr><td>${esc(l.created_at)}</td><td>${esc(l.action)}</td><td>${esc(l.detail)}</td></tr>`).join("");
  res.type("html").send(render("dashboard.html", {
    username: esc(req.session.adminUsername || "admin"),
    userCount: stats.users,
    activeCount: stats.active,
    totalPoints: stats.points.toLocaleString("vi-VN"),
    logCount: stats.logs,
    userRows: userRows || '<tr><td colspan="6">Chưa có dữ liệu</td></tr>',
    logRows: logRows || '<tr><td colspan="3">Chưa có hoạt động</td></tr>'
  }));
});

app.post("/admin/users", requireAdmin, (req, res) => {
  const name = safeText(req.body.display_name, 80);
  const email = safeText(req.body.email, 160).toLowerCase();
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).send("Tên và email hợp lệ là bắt buộc. <a href='/admin/dashboard'>Quay lại</a>");
  }
  try {
    const result = db.prepare("INSERT INTO demo_users(display_name,email,points,status) VALUES(?,?,0,'active')").run(name, email);
    addLog.run("USER_CREATED", `Created demo user #${result.lastInsertRowid} (${email})`);
  } catch (err) {
    if (String(err.code).includes("SQLITE_CONSTRAINT")) return res.status(409).send("Email đã tồn tại. <a href='/admin/dashboard'>Quay lại</a>");
    throw err;
  }
  res.redirect("/admin/dashboard");
});
app.post("/admin/users/:id/points", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const points = Number(req.body.points);
  if (!Number.isSafeInteger(id) || id < 1 || !Number.isSafeInteger(points) || points < 0 || points > 100000000) {
    return res.status(400).send("Giá trị không hợp lệ. <a href='/admin/dashboard'>Quay lại</a>");
  }
  const result = db.prepare("UPDATE demo_users SET points=? WHERE id=?").run(points, id);
  if (result.changes) addLog.run("DEMO_POINTS_UPDATED", `Set demo points for user #${id} to ${points}`);
  res.redirect("/admin/dashboard");
});
app.post("/admin/users/:id/status", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const status = req.body.status;
  if (!Number.isSafeInteger(id) || id < 1 || !["active","paused"].includes(status)) {
    return res.status(400).send("Giá trị không hợp lệ. <a href='/admin/dashboard'>Quay lại</a>");
  }
  const result = db.prepare("UPDATE demo_users SET status=? WHERE id=?").run(status, id);
  if (result.changes) addLog.run("USER_STATUS_UPDATED", `Set demo user #${id} status to ${status}`);
  res.redirect("/admin/dashboard");
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).send("Đã xảy ra lỗi máy chủ.");
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Move2Earn demo server listening on 127.0.0.1:${PORT}`);
});
